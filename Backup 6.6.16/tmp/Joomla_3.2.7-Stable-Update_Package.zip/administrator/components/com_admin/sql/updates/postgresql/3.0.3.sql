ALTER TABLE "#__associations" ALTER COLUMN id TYPE integer;
